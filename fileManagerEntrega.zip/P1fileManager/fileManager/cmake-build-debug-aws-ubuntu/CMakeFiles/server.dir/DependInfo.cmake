
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/ubuntu/PSD_Dist/fileManager/fileManager/clientManager.cpp" "CMakeFiles/server.dir/clientManager.cpp.o" "gcc" "CMakeFiles/server.dir/clientManager.cpp.o.d"
  "/home/ubuntu/PSD_Dist/fileManager/fileManager/server.cpp" "CMakeFiles/server.dir/server.cpp.o" "gcc" "CMakeFiles/server.dir/server.cpp.o.d"
  "/home/ubuntu/PSD_Dist/fileManager/fileManager/utils.cpp" "CMakeFiles/server.dir/utils.cpp.o" "gcc" "CMakeFiles/server.dir/utils.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
